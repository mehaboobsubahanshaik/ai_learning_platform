import { useState, useEffect } from "react";
import { generateLearningPlan } from "../services/aiService.js";
import { useAuth } from "../services/AuthContext.jsx";
import {
  saveChatMessage,
  getChatHistory,
  saveUserQuery,
  saveQuizQuestions,
  saveUserVideos,
} from "../services/dbService.js";

const YT_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;

export default function ChatBot() {
  const { user } = useAuth();
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const history = await getChatHistory(user.uid);
      if (history.length > 0) {
        setMessages(history);
      } else {
        setMessages([
          { role: "assistant", content: "Hi! Ask me anything about learning, topics, coding, or tech!" },
        ]);
      }
    })();
  }, [user]);

  const send = async () => {
    if (!input.trim()) return;

    const userMsg = { role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    if (user) {
      await saveChatMessage(user.uid, "user", input);
      await saveUserQuery(user.uid, input);
    }

    setInput("");
    setLoading(true);

    try {
      // 🔹 Generate learning plan
      const plan = await generateLearningPlan(input);
      const botMsg = { role: "assistant", content: plan.response };
      setMessages((prev) => [...prev, botMsg]);

      if (user) {
        await saveChatMessage(user.uid, "assistant", plan.response);

        // 🔹 Save quiz question
        await saveQuizQuestions(user.uid, input, [
          { question: `What is the key takeaway from: ${input}?`, options: ["A", "B", "C", "D"], answer: "A" },
        ]);

        // 🔹 Fetch YouTube videos related to user's query
        const ytUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(
          input
        )}&key=${YT_KEY}&maxResults=3&type=video`;
        const ytRes = await fetch(ytUrl);
        const ytData = await ytRes.json();

        if (ytData.items?.length > 0) {
          const videos = ytData.items.map((v) => ({
            id: v.id.videoId,
            title: v.snippet.title,
            thumbnail: v.snippet.thumbnails.default.url,
          }));
          await saveUserVideos(user.uid, input, videos);
        }
      }
    } catch (err) {
      console.error("AI generation failed:", err);
      setMessages((prev) => [...prev, { role: "assistant", content: "⚠️ Sorry, I couldn’t answer right now." }]);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="card">
        <h3>AI Chatbot</h3>
        <p className="small">Please login to start chatting.</p>
      </div>
    );
  }

  return (
    <div className="card stack">
      <h3>AI Chatbot</h3>
      <div
        className="stack"
        style={{
          maxHeight: 320,
          overflowY: "auto",
          background: "#0e0f14",
          padding: 12,
          borderRadius: 12,
        }}
      >
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              background: m.role === "assistant" ? "#141621" : "#0f1116",
              border: "1px solid #242634",
              padding: 10,
              borderRadius: 10,
            }}
          >
            <strong>{m.role === "assistant" ? "Assistant" : "You"}:</strong> {m.content}
          </div>
        ))}
        {loading && <div className="small">Generating…</div>}
      </div>

      <div className="row">
        <input
          className="input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me anything..."
        />
        <button className="btn primary" onClick={send} disabled={loading}>
          {loading ? "..." : "Send"}
        </button>
      </div>
    </div>
  );
}

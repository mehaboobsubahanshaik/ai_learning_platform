//src/components/Footer.jsx
export default function Footer(){
  return (
    <footer className="container small">
      <div className="card" style={{textAlign:"center"}}>
        © {new Date().getFullYear()} Developed by suhan & pavan Dept of CSE&BS at RGMCET
      </div>
    </footer>
  );
}

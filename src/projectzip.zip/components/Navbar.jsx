//src/components/Navbar.jsx
import { Link, useLocation } from "react-router-dom";
import { signOut } from "../services/dbService.js";
import { useAuth } from "../services/AuthContext.jsx";
import { useState } from "react";

export default function Navbar() {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const navLink = (to, label) => (
    <Link to={to} onClick={() => setMenuOpen(false)} className={pathname === to ? "badge" : ""}>
      {label}
    </Link>
  );

  return (
    <header className="nav">
      <div className="nav-inner">
        <div className="brand">
          <span style={{ color: "var(--brand)" }}>▲</span>
          <span>AI Learning Platform</span>
          <span className="badge">Smart</span>
        </div>

        {/* Desktop */}
        <nav className="nav-links desktop">
          {navLink("/", "Home")}
          {navLink("/dashboard", "Dashboard")}
          {navLink("/quiz", "Quiz")}
          {navLink("/videos", "Videos")}
          {navLink("/profile", "Profile")}
          {user ? (
            <button className="btn" onClick={signOut}>Logout</button>
          ) : (
            <Link className="btn primary" to="/login">Login</Link>
          )}
        </nav>

        {/* Mobile Toggle */}
        <button className="btn mobile-toggle" onClick={() => setMenuOpen(!menuOpen)}>☰</button>
      </div>

      {/* Mobile Dropdown */}
      {menuOpen && (
        <div className="mobile-menu card stack">
          {navLink("/", "Home")}
          {navLink("/dashboard", "Dashboard")}
          {navLink("/quiz", "Quiz")}
          {navLink("/videos", "Videos")}
          {navLink("/profile", "Profile")}
          {user ? (
            <button className="btn" onClick={signOut}>Logout</button>
          ) : (
            <Link className="btn primary" to="/login">Login</Link>
          )}
        </div>
      )}
    </header>
  );
}

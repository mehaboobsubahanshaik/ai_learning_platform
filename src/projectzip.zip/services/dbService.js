import { auth, db } from "./firebaseConfig.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
} from "firebase/auth";
import {
  doc,
  setDoc,
  getDoc,
  collection,
  addDoc,
  getDocs,
  serverTimestamp,
  query,
  where,
  orderBy,
} from "firebase/firestore";

/* -------------------
   AUTH HELPERS
------------------- */
export async function signUpWithEmail(email, password) {
  const userCred = await createUserWithEmailAndPassword(auth, email, password);
  return userCred.user;
}

export async function loginWithEmail(email, password) {
  const userCred = await signInWithEmailAndPassword(auth, email, password);
  return userCred.user;
}

export async function signOut() {
  await fbSignOut(auth);
  window.location.href = "/";
}

/* -------------------
   LEARNING PATH
------------------- */
export async function saveLearningPath(uid, path) {
  const ref = doc(db, "learningPaths", uid);
  await setDoc(ref, { uid, path }, { merge: true }); // ✅ add uid for rules
}

export async function getLearningPath(uid) {
  if (!uid) return [];
  const ref = doc(db, "learningPaths", uid);
  const snap = await getDoc(ref);
  return snap.exists() ? snap.data().path : [];
}

/* -------------------
   QUIZ (Results + Questions)
------------------- */
export async function saveQuizResult(uid, topic, score, total) {
  const ref = collection(db, "quizResults");
  await addDoc(ref, {
    uid,
    topic,
    score,
    total,
    createdAt: serverTimestamp(),
  });
}

export async function getQuizResults(uid) {
  const q = query(collection(db, "quizResults"), where("uid", "==", uid));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data());
}

export async function saveQuizQuestions(uid, queryText, questions) {
  const ref = collection(db, "quizQuestions");
  await addDoc(ref, {
    uid,
    query: queryText,
    questions,
    createdAt: serverTimestamp(),
  });
}

export async function getQuizQuestions(uid) {
  const ref = collection(db, "quizQuestions");
  const q = query(ref, where("uid", "==", uid), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data());
}

/* -------------------
   CHATBOT HISTORY
------------------- */
export async function saveChatMessage(uid, role, content) {
  const ref = collection(db, "chatHistory");
  await addDoc(ref, {
    uid,
    role,
    content,
    createdAt: serverTimestamp(),
  });
}

export async function getChatHistory(uid) {
  if (!uid) return [];
  const ref = collection(db, "chatHistory");
  const q = query(ref, where("uid", "==", uid), orderBy("createdAt", "asc"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ ...d.data(), id: d.id }));
}

/* -------------------
   USER QUERIES (for VideoPage)
------------------- */
export async function saveUserQuery(uid, queryText) {
  const ref = collection(db, "userQueries");
  await addDoc(ref, {
    uid,
    query: queryText,
    createdAt: serverTimestamp(),
  });
}

export async function getUserQueries(uid) {
  const ref = collection(db, "userQueries");
  const q = query(ref, where("uid", "==", uid), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map((doc) => doc.data());
}

/* -------------------
   VIDEO STORAGE (🔥 NEW)
------------------- */
export async function saveUserVideos(uid, queryText, videos) {
  const ref = collection(db, "userVideos");
  await addDoc(ref, {
    uid,
    query: queryText,
    videos,
    createdAt: serverTimestamp(),
  });
}

export async function getUserVideos(uid) {
  const ref = collection(db, "userVideos");
  const q = query(ref, where("uid", "==", uid), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data());
}

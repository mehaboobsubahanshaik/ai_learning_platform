// src/services/aiService.js
// Uses ONLY Gemini API to generate learning content

import axios from "axios";

const GEMINI_KEY = import.meta.env.VITE_GEMINI_API_KEY;

if (!GEMINI_KEY) {
  console.error("❌ Gemini API key missing. Please set VITE_GEMINI_API_KEY in your .env file.");
}

/* --------------------
   MAIN FUNCTION
-------------------- */
export async function generateLearningPlan(userPrompt) {
  if (!GEMINI_KEY) {
    throw new Error("Gemini API key is not configured.");
  }

  try {
    // ✅ Updated to latest Gemini 2.5 Flash endpoint (old one caused 404)
    const url =
      "https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=" +
      GEMINI_KEY;

    const body = {
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `Create a concise 5-day learning plan with lessons, quizzes, and video recommendations for: ${userPrompt}`,
            },
          ],
        },
      ],
    };

    const res = await axios.post(url, body);

    // ✅ Expanded to handle Gemini 2.x structured responses
    let text =
      res?.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      res?.data?.candidates?.[0]?.content?.parts?.[0]?.content ||
      res?.data?.candidates?.[0]?.output ||
      res?.data?.output_text ||
      res?.data?.candidates?.[0]?.content?.parts?.[0]?.data ||
      "Unable to generate content";

    if (!text) throw new Error("Gemini response was empty.");

    // ✅ Log raw response for debugging (can remove later)
    console.log("✅ Gemini raw response:", text);

    return { response: text.trim() };
  } catch (err) {
    console.error("Gemini API error:", err.response?.data || err.message);
    throw new Error("Failed to generate learning plan with Gemini.");
  }
}

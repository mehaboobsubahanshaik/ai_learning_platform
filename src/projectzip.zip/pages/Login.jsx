//src/pages/Login.jsx
import { useState } from "react";
import { loginWithEmail, signUpWithEmail } from "../services/authService";

export default function Login() {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = async () => {
    try {
      if (mode === "login") {
        await loginWithEmail(email, password);
        alert("Login successful!");
      } else {
        await signUpWithEmail(email, password);
        alert("Account created!");
      }
      window.location.href = "/dashboard";
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="container">
      <div className="card" style={{ maxWidth: 420, margin: "auto" }}>
        <h2>{mode === "login" ? "Login" : "Create Account"}</h2>
        <label className="label">Email</label>
        <input
          className="input"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <label className="label">Password</label>
        <input
          className="input"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <div className="row" style={{ marginTop: 12, justifyContent: "space-between" }}>
          <button className="btn primary" onClick={submit}>
            {mode === "login" ? "Login" : "Sign up"}
          </button>
          <button className="btn" onClick={() => setMode(mode === "login" ? "signup" : "login")}>
            {mode === "login" ? "Need an account? Sign up" : "Already have an account? Login"}
          </button>
        </div>
      </div>
    </div>
  );
}

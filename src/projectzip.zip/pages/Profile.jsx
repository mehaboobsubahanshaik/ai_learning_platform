// src/pages/Profile.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../services/AuthContext.jsx";
import { getLearningPath } from "../services/dbService.js";

export default function Profile() {
  const { user } = useAuth();
  const [path, setPath] = useState([]);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    (async () => {
      const data = await getLearningPath(user.uid);
      setPath(data || []);
      if (data?.length) {
        const pct = Math.round(
          (data.filter((p) => p.done).length / data.length) * 100
        );
        setProgress(pct);
      }
      setLoading(false);
    })();
  }, [user]);

  if (!user) {
    return <div className="container">Please login.</div>;
  }

  if (loading) {
    return <div className="container">Loading profile...</div>;
  }

  return (
    <div className="container grid">
      {/* Profile Info */}
      <div className="card">
        <h2>Profile</h2>
        <div className="small">UID</div>
        <div>{user.uid}</div>
        <div className="small" style={{ marginTop: 10 }}>Email</div>
        <div>{user.email}</div>
      </div>

      {/* Stats */}
      <div className="card">
        <h2>Stats</h2>
        <div className="small">Overall Progress</div>
        <h3>{progress}%</h3>
      </div>

      {/* Recent Path Items */}
      <div className="card">
        <h2>Recent Path Items</h2>
        {path.length ? (
          <ul>
            {path.slice(0, 5).map((p, i) => (
              <li key={i}>
                {p.title || "Untitled"} {p.done ? "✅" : ""}
              </li>
            ))}
          </ul>
        ) : (
          <div className="small">No path items found.</div>
        )}
      </div>
    </div>
  );
}

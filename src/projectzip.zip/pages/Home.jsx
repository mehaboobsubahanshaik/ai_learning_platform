//src/pages/Home.jsx
import ChatBot from "../components/ChatBot.jsx";
import VideoCard from "../components/VideoCard.jsx";

export default function Home(){
  return (
    <div className="container stack">
      <div className="grid">
        <div className="kpi">
          <div className="small">Vision</div>
          <h3>Personalized, adaptive, engaging learning for everyone.</h3>
        </div>
        <div className="kpi">
          <div className="small">Mission</div>
          <h3>Generate multi-format content + dynamic pathways using AI.</h3>
        </div>
        <div className="kpi">
          <div className="small">Real-time</div>
          <h3>Progress tracking, feedback & gamification.</h3>
        </div>
      </div>
      <div className="row">
        <div style={{flex:2, minWidth:300}}>
          <ChatBot />
        </div>
        <div style={{flex:1, minWidth:280}}>
          <VideoCard title="Introduction to the Platform" url="https://www.youtube.com/embed/dQw4w9WgXcQ" />
        </div>
      </div>
    </div>
  );
}

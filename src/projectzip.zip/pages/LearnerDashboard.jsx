// src/pages/LearnerDashboard.jsx
import { useEffect, useState } from "react";
import ProgressTracker from "../components/ProgressTracker.jsx";
import { useAuth } from "../services/AuthContext.jsx";
import { getLearningPath, saveLearningPath } from "../services/dbService.js";

export default function LearnerDashboard() {
  const { user } = useAuth();
  const [path, setPath] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    (async () => {
      const existing = await getLearningPath(user.uid);
      if (existing?.length > 0) {
        setPath(existing);
      } else {
        const starter = [
          { title: "Day 1: Basics", done: false },
          { title: "Day 2: Practice", done: false },
        ];
        setPath(starter);
        await saveLearningPath(user.uid, starter);
      }
      setLoading(false);
    })();
  }, [user]);

  const toggle = async (idx) => {
    const next = path.map((n, i) =>
      i === idx ? { ...n, done: !n.done } : n
    );
    setPath(next);
    if (user) await saveLearningPath(user.uid, next);
  };

  const addTask = async () => {
    const title = prompt("Enter a new learning task:");
    if (!title) return;
    const updated = [...path, { title, done: false }];
    setPath(updated);
    if (user) await saveLearningPath(user.uid, updated);
  };

  const progress = path.length
    ? Math.round((path.filter((x) => x.done).length / path.length) * 100)
    : 0;

  if (!user) {
    return <div className="container">Please login to see your dashboard.</div>;
  }

  if (loading) {
    return <div className="container">Loading your learning path...</div>;
  }

  return (
    <div className="container stack">
      <h2>Your Learning Path</h2>

      <ProgressTracker
        progress={progress}
        streak={Math.max(1, Math.floor(progress / 20))}
      />

      <div className="card stack">
        {path.map((node, idx) => (
          <div
            key={idx}
            className="row"
            style={{ justifyContent: "space-between", alignItems: "center" }}
          >
            <div>{node.title}</div>
            <button
              className={`btn ${node.done ? "primary" : ""}`}
              onClick={() => toggle(idx)}
            >
              {node.done ? "Completed" : "Mark done"}
            </button>
          </div>
        ))}

        <button className="btn primary" onClick={addTask}>
          ➕ Add Task
        </button>
      </div>
    </div>
  );
}
